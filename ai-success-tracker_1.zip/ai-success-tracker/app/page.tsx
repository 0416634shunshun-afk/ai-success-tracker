import { readFileSync } from 'fs';
import { join } from 'path';
import { Story } from './types';
import Header from './components/Header';
import Dashboard from './components/Dashboard';

function getStories(): Story[] {
  const filePath = join(process.cwd(), 'data', 'stories.json');
  const raw = readFileSync(filePath, 'utf-8');
  return JSON.parse(raw) as Story[];
}

export default function Home() {
  const stories = getStories();

  return (
    <div className="min-h-screen relative" style={{ background: 'var(--bg-primary)' }}>
      {/* Subtle background grid */}
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          backgroundImage:
            'linear-gradient(rgba(255,255,255,0.015) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.015) 1px, transparent 1px)',
          backgroundSize: '64px 64px',
        }}
      />

      <main className="relative z-10 max-w-6xl mx-auto px-6 pb-24">
        <Header />
        <Dashboard stories={stories} />
      </main>

      <div
        className="fixed bottom-0 left-0 right-0 h-32 pointer-events-none"
        style={{ background: 'linear-gradient(to top, var(--bg-primary), transparent)' }}
      />
    </div>
  );
}
