import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI Success Tracker",
  description: "Curated global case studies of enterprise AI adoption",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
