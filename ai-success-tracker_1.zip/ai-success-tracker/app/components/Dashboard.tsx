'use client';

import { useState, useMemo } from 'react';
import { Story } from '../types';
import StoryCard from './StoryCard';
import FilterBar from './FilterBar';

interface DashboardProps {
  stories: Story[];
}

export default function Dashboard({ stories }: DashboardProps) {
  const [activeFilter, setActiveFilter] = useState('All');

  const industries = useMemo(
    () => [...new Set(stories.map((s) => s.industry))].sort(),
    [stories]
  );

  const filtered = useMemo(
    () =>
      activeFilter === 'All'
        ? stories
        : stories.filter((s) => s.industry === activeFilter),
    [stories, activeFilter]
  );

  return (
    <div>
      <FilterBar
        industries={industries}
        activeFilter={activeFilter}
        onFilterChange={setActiveFilter}
      />

      {/* Grid */}
      <div
        className="grid gap-5"
        style={{
          gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
        }}
      >
        {filtered.map((story, i) => (
          <div key={story.id} className="animate-fade-in-up" style={{ animationDelay: `${i * 70}ms` }}>
            <StoryCard story={story} index={i} />
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div
          className="text-center py-24"
          style={{ color: 'var(--text-muted)' }}
        >
          <p className="font-display text-2xl mb-2">No stories found</p>
          <p className="text-sm">Try a different filter</p>
        </div>
      )}

      {/* Footer note */}
      <div
        className="mt-16 pt-8 text-center"
        style={{ borderTop: '1px solid var(--border-subtle)' }}
      >
        <p className="text-xs tracking-wider uppercase" style={{ color: 'var(--text-muted)' }}>
          {filtered.length} case{filtered.length !== 1 ? 's' : ''} displayed
          {activeFilter !== 'All' && ` · ${activeFilter}`}
        </p>
      </div>
    </div>
  );
}
