'use client';

import { Story } from '../types';

const industryColors: Record<string, string> = {
  Finance: '#4fc3c3',
  Fintech: '#7b9ef0',
  'Developer Tools': '#a78bfa',
  Biotech: '#6ee7b7',
  EdTech: '#fbbf24',
  Retail: '#f87171',
};

interface StoryCardProps {
  story: Story;
  index: number;
}

export default function StoryCard({ story, index }: StoryCardProps) {
  const accentColor = industryColors[story.industry] || '#d4af37';
  const metricEntries = Object.entries(story.metrics).slice(0, 2);

  return (
    <article
      className="story-card rounded-sm p-6 flex flex-col gap-4 cursor-default"
      style={{
        animationDelay: `${index * 80}ms`,
        animationFillMode: 'both',
      }}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-3">
        {/* Logo */}
        <div
          className="flex-shrink-0 w-10 h-10 rounded-sm flex items-center justify-center text-xs font-medium tracking-widest"
          style={{
            background: `${accentColor}14`,
            border: `1px solid ${accentColor}30`,
            color: accentColor,
            fontFamily: "'DM Sans', sans-serif",
          }}
        >
          {story.logoInitial}
        </div>

        {/* Year badge */}
        <span
          className="text-xs tracking-widest uppercase"
          style={{ color: 'var(--text-muted)', fontVariantNumeric: 'tabular-nums' }}
        >
          {story.year}
        </span>
      </div>

      {/* Company + Country */}
      <div>
        <div className="flex items-baseline gap-2 mb-1">
          <h3
            className="font-display text-base font-medium"
            style={{ color: 'var(--text-primary)' }}
          >
            {story.company}
          </h3>
          <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
            {story.country}
          </span>
        </div>
        <p
          className="text-sm leading-relaxed"
          style={{ color: 'var(--text-secondary)', fontWeight: 300 }}
        >
          {story.title}
        </p>
      </div>

      {/* Divider */}
      <div className="divider-gold" />

      {/* Summary */}
      <p
        className="text-xs leading-relaxed flex-1"
        style={{ color: 'var(--text-secondary)', lineHeight: 1.7 }}
      >
        {story.summary}
      </p>

      {/* Metrics */}
      <div className="grid grid-cols-2 gap-3">
        {metricEntries.map(([key, value]) => (
          <div key={key}>
            <div className="metric-highlight">{value}</div>
            <div
              className="text-xs mt-0.5 uppercase tracking-wider"
              style={{ color: 'var(--text-muted)', fontSize: '0.58rem' }}
            >
              {key.replace(/([A-Z])/g, ' $1').trim()}
            </div>
          </div>
        ))}
      </div>

      {/* Impact bar */}
      <div
        className="rounded-sm px-3 py-2 text-xs"
        style={{
          background: `${accentColor}08`,
          border: `1px solid ${accentColor}20`,
          color: accentColor,
          fontWeight: 400,
        }}
      >
        ↑ {story.impact}
      </div>

      {/* Tags */}
      <div className="flex flex-wrap gap-1.5">
        <span
          className="text-xs mr-1"
          style={{ color: 'var(--text-muted)', fontSize: '0.65rem' }}
        >
          #
        </span>
        {story.tags.map((tag) => (
          <span key={tag} className="tag-pill">
            {tag}
          </span>
        ))}
      </div>
    </article>
  );
}
